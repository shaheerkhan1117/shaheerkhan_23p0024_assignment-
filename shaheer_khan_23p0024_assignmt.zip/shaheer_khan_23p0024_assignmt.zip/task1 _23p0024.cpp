#include <stdio.h>
int main() 
{
    int arr[20][20];
    // Generating random numbers for the 20x20 grid
    for(int i = 0; i < 20; i++) {
        for(int j = 0; j < 20; j++) {
            arr[i][j] = i+j; 
        }}
    printf("Grid is :\n");
    for(int i=0;i<20;i++) 
	{
        for(int j=0;j<20;j++)
		 {
            printf("%d ",arr[i][j]);
        }
        printf("\n");
    }
    int max_product=0;
    char direction='N'; /* Direction variable to store the direction with the highest product

    Check horizontal products to the right of each element*/
    for(int i=0;i<20;i++) 
	{
        for(int j=0;j<17;j++) 
		{
            int product=arr[i][j] * arr[i][j+1] * arr[i][j+2] * arr[i][j+3];
            if(product>max_product) 
			{
                max_product=product;
                direction='H'; /* Horizontal to right and direction is given h which be use to show the product direction to which side the multiplication 
                happened through switch */
            }
        }}
    // to find horizontal products to the left of each element
    for(int i=0;i<20;i++) 
	{
        for(int j=3;j<20;j++)
		 {
            int product=arr[i][j] * arr[i][j-1] * arr[i][j-2] * arr[i][j-3];
            if(product>max_product) 
			{
                max_product=product;
                direction='H'; // Horizontal to left direction is same h
            }}}
    // Check vertical products above each element and it product
    for(int i=0;i<17;i++) 
	{
        for(int j=0;j<20;j++)
		 {
            int product=arr[i][j] * arr[i+1][j] * arr[i+2][j] * arr[i+3][j];
            if (product>max_product) 
			{
                max_product=product;
                direction='V'; // Vertical product of upper elements of that number and direction is given v
            }
        }}
    // Check vertical products below each element
    for (int i = 3; i < 20; i++) {
        for (int j = 0; j < 20; j++) {
            int product = arr[i][j] * arr[i - 1][j] * arr[i - 2][j] * arr[i - 3][j];
            if (product > max_product) {
                max_product = product;
                direction = 'V'; // Vertical product of lowwwer elements of the number and direction is same as upper vertical
            }
        }
    }

    // to find diagonal products in both upright and downright directions
    for(int i=0;i<17;i++) 
	{
        for(int j=0;j<17;j++) 
		{
            int product1=arr[i][j] * arr[i+1][j+1] * arr[i+2][j+2] * arr[i+3][j+3];
            if(product1>max_product) 
			{
                max_product=product1;
                direction='D'; // diagonal downright and direction is d
            }
            int product2 = arr[i + 3][j] * arr[i + 2][j + 1] * arr[i + 1][j + 2] * arr[i][j + 3];
            if (product2 > max_product) {
                max_product = product2;
                direction = 'U'; // diagonal upright
            }
        }}
    printf("Largest Product: %d\n", max_product);
    printf("Direction: ");
    switch (direction) 
	{
        case 'H':
            printf("Horizontal\n");
            break;
        case 'V':
            printf("Vertical\n");
            break;
        case 'D':
            printf("Diagonal down-right\n");
            break;
        case 'U':
            printf("Diagonal up-right\n");
            break;
        default:
            printf("Unknown\n");
    }

    return 0;
}
