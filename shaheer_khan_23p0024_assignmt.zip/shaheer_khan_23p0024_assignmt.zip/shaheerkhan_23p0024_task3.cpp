#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define HAND_SIZE 5
// Function to parse card ranks and suits
void parseCard(char card[], char *rank, char *suit)
 {
    *rank = card[0];
    *suit = card[1];
}
// Function to compare two cards by rank
int compareCards(char rank1, char rank2)
 {
    if (rank1 == rank2)
        return 0;
    else if (rank2 == 'A')
        return -1;
    else if (rank1 == 'A')
        return 1;
    else if (rank2 == 'K')
        return -1;
    else if (rank1 == 'K')
        return 1;
    else if (rank2 == 'Q')
        return -1;
    else if (rank1 == 'Q')
        return 1;
    else if (rank2 == 'J')
        return -1;
    else if (rank1 == 'J')
        return 1;
    else if (rank2 == 'T')
        return -1;
    else if (rank1 == 'T')
        return 1;
    else
        return (rank1-rank2);
}
// Function to determine if a hand is a flush
int isFlush(char hand[])
 {
    char suit=hand[1];
    int i=3;
    do 
	{
        if(hand[i+1]!=suit)
            return 0;
        i+=3;
    } 
	while(i<HAND_SIZE*3);
    return 1;
}
// Function to determine if a hand is a straight
int isStraight(char ranks[])
 {
    int i=0;
    do {
        if(ranks[i]!=ranks[i+1]-1)
            return 0;
        i++;
    } 
	while(i<HAND_SIZE-1);
    return 1;
}
// Function to determine the winning player for a set of poker hands
void determineWinner(char player1[],char player2[])
 {
    int wins_player1=0,wins_player2=0;
    char ranks[]="23456789TJQKA";
    int i=0;
    do {
        char rank_player1, suit_player1, rank_player2, suit_player2;
        parseCard(&player1[i*3],&rank_player1,&suit_player1);
        parseCard(&player2[i*3],&rank_player2,&suit_player2);
        int rank_index_player1=strchr(ranks,rank_player1)-ranks;
        int rank_index_player2=strchr(ranks,rank_player2)-ranks;
        // Compare ranks for straight and high card
        if(rank_index_player1!=rank_index_player2)
		 {
            if(rank_index_player1>rank_index_player2)
                wins_player1++;
            else
                wins_player2++;
        }
        i++;
    } 
	while(i<HAND_SIZE);
    if(wins_player1 > wins_player2)
        printf("Player 1 wins\n");
    else if(wins_player2 > wins_player1)
        printf("Player 2 wins\n");
    else
        printf("It's a tie\n");
}
int main() 
{
    // Example input
    char hands[5][40] = {
	    "2H 3H 4H 5H 6H 2C 3C 4C 5C 6C", // Player 1 wins with straight flush
	    "2H 3H 4H 5H 6S 2C 3C 4C 5C 6C", // Player 1 wins with straight
	    "2H 2S 2D 3H 3S 2C 3C 4C 5C 6C", // Player 1 wins with three of a kind
	    "2H 3H 4H 5H 7H 2C 3C 4C 5C 6C", // Player 1 wins with flush
	    "2H 3H 4H 5H 7S 2C 3C 4C 5C 6C"  // Player 1 wins with high card
	};
    int i=0;
	do{
	    char *player1=hands[i];
	    char *player2=hands[i]+15;
	    printf("Hand %d: ",i+1);
	    determineWinner(player1, player2);
	    i++;
	} 
	while(i<5);
    return 0;
}

