#include <stdio.h>
int find_length(int num)
    {
    int len=1; // represent length
    do 
	 {
        if(num%2==0)
		 {
            num=num/2;
        } 
		else if(num%2==1)
		 {
            num=num*3+1;
        }
        ++len;
    } 
	while(num>1); // Continue until num becomes 1
    return len; /* return length to main of passed value */
}
int main() 
{
    int val, Long_num, max = 0, temp; 
    printf("---------------Enter a num to apply sequence---------\n");
    scanf("%d", &val);
    if(val<=0)
       val=-(val);  // taking non positive inputs as a positive number to prevent error
    temp=val;  //temp used so that orignal value do not change
    for(int i=1;i<=temp;i++)
	 { 
        int length= find_length(i); /* passing the valuse to function which find the length of the sequence by sending each num 
        to upper function as aparameter and the return value from it will be store in length variable*/
        if(length>max)
		 {
            max=length; //max is used to store the maximum length  
            Long_num=i;//lon num i used to store the longest streak 
        }
    }
    printf("\n======  Longest streak is on num  %d  =========\n", Long_num);
    printf("==== Maximum length is %d  ==========\n", max);
}

